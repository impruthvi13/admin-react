import React from 'react'
import logo from '../../assets/images/logo.svg'
function AuthLeftLogo () {
  return (
    <>
       <div className="ollato-logo-sec">
          <div className="logo-box">
            <img src={logo} alt="logo" />
          </div>
        </div>
    </>
  )
}

export default AuthLeftLogo
