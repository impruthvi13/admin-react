import React, { useState, useEffect, useRef } from 'react'
/* React Packages */
import { Nav, Tab, Form } from 'react-bootstrap'
import BootstrapTable from 'react-bootstrap-table-next'
import paginationFactory from 'react-bootstrap-table2-paginator'
import { Link } from 'react-router-dom'
import { useDispatch, useSelector } from 'react-redux'
import { useSnackbar } from 'react-notistack'

/* Components */
import AcceptModal from '../../../Components/AcceptModal'
import RejectModal from '../../../Components/RejectModal'

import counsimg from '../../../assets/images/couns.png'

import view from '../../../assets/images/view-eye.svg'

import { acceptRejectAction } from '../../../Actions/Counsellor/session'
import { getAllSession } from '../../../Actions/Admin/session'
import moment from 'moment'
import ls from 'localstorage-slim'
// import localStorage from 'react-secure-storage'

const counsellorinfo = (row, cell) => {
  return (
    <div className='counsellor-infobox'>
      <img src={counsimg} alt='' />
      <div className='counsinfo'>
        <p>
          {cell?.student?.first_name} {cell?.student?.last_name}
        </p>
        <a className='email-text' href=''>
          {cell?.student?.email}
        </a>
      </div>
    </div>
  )
}
const dateTimeInfo = (row, cell) => {
  return (
    <div className='counsellor-infobox'>
      {/* <img src={counsimg} alt='' /> */}
      <div className='counsinfo'>
        <p>{cell?.date}</p>
        <a className='email-text' href=''>
          {cell?.from_time}
        </a>
      </div>
    </div>
  )
}

const Sessions = () => {
  const token = localStorage.getItem('token')
  const dispatch = useDispatch()
  const { enqueueSnackbar } = useSnackbar()
  const [startDate, setStartDate] = useState()
  const profile = JSON.parse(localStorage.getItem('profile'))
  const adminType = ls.get('admin-type', { decrypt: true, secret: profile?.id })

  // useSelector
  const sessionData = useSelector(
    (state) => state.sessionsAdmin.sessionDataArray
  )
  const count = useSelector((state) => state.sessionsAdmin.sessionCount)
  const isAcceptRejectFlag = useSelector(
    (state) => state.session.isAcceptReject
  )
  const resMessageFlag = useSelector((state) => state.session.resMessage)
  const isReportedFlag = useSelector((state) => state.session.isReported)

  // previousProps
  const previousProps = useRef({
    isAcceptRejectFlag,
    resMessageFlag,
    isReportedFlag
  }).current

  // useState
  const [key, setKey] = useState('all')
  const [start, setStart] = useState(0)
  const [limit] = useState(10)
  const [sort] = useState('date')
  const [pageNo, setPageNo] = useState(1)
  const [show, setShow] = useState(false)
  const [showReject, setShowReject] = useState(false)
  const [id] = useState('')

  const handleClose = () => setShow(false)

  const handleRejectClose = () => setShowReject(false)

  const actionbutton = (row, cell) => {
    return (
      <>
        <Link to='/admin/session-details' state={{ id: cell }}>
          <button
            className='action-btns green-bg img-btn'
            type='button'
            // onClick={() => handleShow(cell?.id)}
          >
            {' '}
            <img className='mr-0' src={view} alt='' />
          </button>
        </Link>
      </>
    )
  }

  const columns = [
    {
      dataField: 'id',
      text: 'Sr. no.'
    },
    {
      dataField: 'studentdetails',
      text: 'Student Details',
      formatter: counsellorinfo
    },
    {
      dataField: 'date',
      text: 'Date & Time',
      formatter: dateTimeInfo
    },
    {
      dataField: 'body',
      text: 'Action',
      formatter: actionbutton
    }
  ]
  const products = sessionData || []

  useEffect(() => {
    if (key) {
      if (adminType === 'center') {
        dispatch(getAllSession(start, limit, sort, key, startDate, token, 'center'))
      } else {
        dispatch(getAllSession(start, limit, sort, key, startDate, token, 'admin'))
      }
    }
    console.log(key)
  }, [key])

  // Pagination
  const onPageChange = (page, sizePerPage) => {
    setPageNo(page)

    setStart(limit * (page - 1) - 1 < 0 ? 0 : limit * (page - 1))
    if (page === 1) {
      if (adminType === 'center') {
        dispatch(getAllSession(0, limit, sort, key, startDate, token, 'center'))
      } else {
        dispatch(getAllSession(0, limit, sort, key, startDate, token, 'admin'))
      }
    } else {
      if (adminType === 'center') {
        dispatch(
          getAllSession(
            limit * (page - 1) - 1 < 0 ? 0 : limit * (page - 1),
            limit,
            sort,
            key,
            startDate,
            token,
            'center'
          )
        )
      } else {
        dispatch(
          getAllSession(
            limit * (page - 1) - 1 < 0 ? 0 : limit * (page - 1),
            limit,
            sort,
            key,
            startDate,
            token,
            'admin'
          )
        )
      }
    }
  }

  console.log('id', id)

  const options = {
    sizePerPage: limit,
    hideSizePerPage: true,
    hidePageListOnlyOnePage: false,
    alwaysShowAllBtns: true,
    totalSize: count,
    remote: { pagination: true },
    onPageChange,
    page: +pageNo
  }

  // Sorting
  const defaultSortedBy = [
    {
      dataField: 'name',
      order: 'asc'
    }
  ]

  const handleTablechange = (type, { page, sortField, sortOrder }) => {
    if (type === 'sort') {
      if (sortOrder) {
        if (adminType === 'center') {
          dispatch(getAllSession(start, limit, sort, key, startDate, token, 'center'))
        } else {
          dispatch(getAllSession(start, limit, sort, key, startDate, token, 'admin'))
        }
      }
    }
  }

  const emptyDataMessage = () => {
    return 'No Data'
  }

  const handleAcceptReject = (id) => {
    const dataObject = {
      isAccept: true,
      sessionId: id
    }
    if (dataObject) {
      dispatch(acceptRejectAction(dataObject, token))
    }
  }

  const handleReject = (id) => {
    const dataObject = {
      isAccept: false,
      sessionId: id
    }
    if (dataObject) {
      dispatch(acceptRejectAction(dataObject, token))
    }
  }

  // Toastify Notification
  useEffect(() => {
    if (previousProps?.isAcceptRejectFlag !== isAcceptRejectFlag) {
      if (isAcceptRejectFlag) {
        setShow(false)
        setShowReject(false)
        enqueueSnackbar(`${resMessageFlag}`, {
          variant: 'success',
          hide: 2000,
          autoHide: true
        })
        if (adminType === 'center') {
          dispatch(getAllSession(0, limit, sort, key, '', token, 'center'))
        } else {
          dispatch(getAllSession(0, limit, sort, key, '', token, 'admin'))
        }
      } else if (isAcceptRejectFlag === false) {
        setShow(false)
        setShowReject(false)
        enqueueSnackbar(`${resMessageFlag}`, {
          variant: 'error',
          hide: 2000,
          autoHide: true,
          TransitionComponent: 'Fade'
        })
      }
    }
    return () => {
      previousProps.isAcceptRejectFlag = isAcceptRejectFlag
    }
  }, [isAcceptRejectFlag])

  useEffect(() => {
    if (startDate) {
      if (adminType === 'center') {
        dispatch(getAllSession(0, limit, sort, key, moment(startDate).format('YYYY-MM-DD'), token, 'center'))
      } else {
        dispatch(getAllSession(0, limit, sort, key, moment(startDate).format('YYYY-MM-DD'), token, 'admin'))
      }
    } else {
      if (adminType === 'center') {
        dispatch(getAllSession(0, limit, sort, key, '', token, 'center'))
      } else {
        dispatch(getAllSession(0, limit, sort, key, '', token, 'admin'))
      }
    }
  }, [startDate])

  return (
    <>
      {/* <Header /> */}
      <div>
        <div className='session-history-box'>
          <Tab.Container
            id='left-tabs-example'
            defaultActiveKey='all'
            activeKey={key}
            onSelect={(k) => {
              setKey(k)
            }}
          >
            <div className='d-flex justify-content-between align-items-center heading-box '>
              <Nav variant='pills'>
                <Nav.Item>
                  <Nav.Link eventKey='all'>All</Nav.Link>
                </Nav.Item>
                <Nav.Item>
                  <Nav.Link eventKey='panding'>Pending</Nav.Link>
                </Nav.Item>
                <Nav.Item>
                  <Nav.Link eventKey='upcoming'>Ongoing</Nav.Link>
                </Nav.Item>
                <Nav.Item>
                  <Nav.Link eventKey='completed'>Completed</Nav.Link>
                </Nav.Item>
                <Nav.Item>
                  <Nav.Link eventKey='cancel'>Canceled</Nav.Link>
                </Nav.Item>
                <Nav.Item>
                  <Nav.Link eventKey='reschedule'>Rescheduled</Nav.Link>
                </Nav.Item>
              </Nav>
              <Form>
              <div className=''>
                    <div className='row'>
                      <div className='col-lg-12'>
                        <Form.Group
                          className="form-group mb-0"
                          controlId='formdate'
                        >
                            <Form.Label>Select Date</Form.Label>
                          <Form.Control
                            type='date'
                            className='mb-0'
                            onChange={(e) => setStartDate(e.target.value)}
                            name={name}
                          />
                            <Form.Text className='error-msg'>
                            </Form.Text>
                        </Form.Group>
                      </div>
                    </div>
              </div>
            </Form>
              {/* <DatePicker selected={startDate} onChange={(date) => setStartDate(date)} format='yyyy-MM-dd' placeholderText='Select date' className='p-1'/> */}
            </div>
            <Tab.Content className='overflow-auto'>
              <Tab.Pane eventKey='all'>
                <BootstrapTable
                  keyField='id'
                  data={products}
                  columns={columns}
                  remote={true}
                  pagination={paginationFactory(options)}
                  defaultSorted={defaultSortedBy}
                  onTableChange={handleTablechange}
                  responsive='md'
                  options={options}
                  noDataIndication={() => emptyDataMessage()}
                />
                {/* <h6 className='pending-sessions text-start'>Showing 7 from {count}</h6> */}
              </Tab.Pane>
              <Tab.Pane eventKey='panding'>
                <BootstrapTable
                  keyField='id'
                  data={products}
                  columns={columns}
                  remote={true}
                  pagination={paginationFactory(options)}
                  defaultSorted={defaultSortedBy}
                  onTableChange={handleTablechange}
                  responsive='md'
                  options={options}
                  noDataIndication={() => emptyDataMessage()}
                />
                {/* <h6 className='pending-sessions text-start'>Showing 7 from {count}</h6> */}
              </Tab.Pane>
              <Tab.Pane eventKey='upcoming'>
                <BootstrapTable
                  keyField='id'
                  data={products}
                  columns={columns}
                  remote={true}
                  pagination={paginationFactory(options)}
                  defaultSorted={defaultSortedBy}
                  onTableChange={handleTablechange}
                  responsive='md'
                  options={options}
                  noDataIndication={() => emptyDataMessage()}
                />
                {/* <h6 className='pending-sessions text-start'>Showing 7 from {count}</h6> */}
              </Tab.Pane>
              <Tab.Pane eventKey='completed'>
                <BootstrapTable
                  keyField='id'
                  data={products}
                  columns={columns}
                  remote={true}
                  pagination={paginationFactory(options)}
                  defaultSorted={defaultSortedBy}
                  onTableChange={handleTablechange}
                  responsive='md'
                  options={options}
                  noDataIndication={() => emptyDataMessage()}
                />
                {/* <h6 className='pending-sessions text-start'>Showing 7 from {count}</h6> */}
              </Tab.Pane>
              <Tab.Pane eventKey='cancel'>
                <BootstrapTable
                  keyField='id'
                  data={products}
                  columns={columns}
                  remote={true}
                  pagination={paginationFactory(options)}
                  defaultSorted={defaultSortedBy}
                  onTableChange={handleTablechange}
                  responsive='md'
                  options={options}
                  noDataIndication={() => emptyDataMessage()}
                />
                {/* <h6 className='pending-sessions text-start'>Showing 7 from {count}</h6> */}
              </Tab.Pane>
              <Tab.Pane eventKey='reschedule'>
                <BootstrapTable
                  keyField='id'
                  data={products}
                  columns={columns}
                  remote={true}
                  pagination={paginationFactory(options)}
                  defaultSorted={defaultSortedBy}
                  onTableChange={handleTablechange}
                  responsive='md'
                  options={options}
                  noDataIndication={() => emptyDataMessage()}
                />
              </Tab.Pane>
            </Tab.Content>
          </Tab.Container>
        </div>
      </div>
      <AcceptModal
        id={id}
        show={show}
        handleClose={handleClose}
        handleAcceptReject={handleAcceptReject}
      />
      <RejectModal
        id={id}
        show={showReject}
        handleClose={handleRejectClose}
        handleAcceptReject={handleReject}
      />
    </>
  )
}

export default Sessions
