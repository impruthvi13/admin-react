import React, { useEffect, useRef, useState } from 'react'
import { Form } from 'react-bootstrap'
import { useDispatch, useSelector } from 'react-redux'
import {
  centerPackages,
  purchasePackageAction,
  purchasePackageSucees
} from '../../../Actions/Center/purchaseLicense'
import TitleHeader from '../../../Components/TitleHeader'
import { useSnackbar } from 'react-notistack'
import { useNavigate } from 'react-router-dom'

function PurchaseCredit () {
  const [count, setCount] = useState([])
  const dispatch = useDispatch()
  const navigate = useNavigate()
  const token = localStorage.getItem('token')
  const profile = JSON.parse(localStorage.getItem('profile'))
  const { enqueueSnackbar } = useSnackbar()

  // useSelector
  const packageData = useSelector((state) => state.centerPackages.packageData)
  const packagePurchasedData = useSelector(
    (state) => state.centerPackages.packagePurchasedDetails
  )
  const isPackagePurchaseFlag = useSelector(
    (state) => state.centerPackages.isPackagePurchase
  )
  const responseMessage = useSelector(
    (state) => state.centerPackages.ressMessage
  )
  const previousProps = useRef({
    packagePurchasedData,
    isPackagePurchaseFlag
  }).current
  console.log('packageData', packageData)
  console.log(packagePurchasedData)

  useEffect(() => {
    dispatch(centerPackages(token))
  }, [])

  console.log(profile)

  useEffect(() => {
    if (previousProps?.packagePurchasedData !== packagePurchasedData) {
      if (packagePurchasedData) {
        const options = {
          key: 'rzp_test_zNZiB3KgbnDuIG', // Enter the Key ID generated from the Dashboard
          amount: Number(packagePurchasedData?.amount),
          currency: packagePurchasedData?.currency,
          name: profile?.title,
          // description: data?.title,
          email: profile?.email,
          image: {},
          order_id: packagePurchasedData?.id,
          handler: function (response) {
            const data = {
              razorpay_payment_id: response?.razorpay_payment_id,
              razorpay_order_id: response?.razorpay_order_id,
              razorpay_signature: response?.razorpay_signature
            }
            dispatch(purchasePackageSucees(data, token))
          },
          prefill: {
            name: profile?.title,
            email: profile?.email,
            contact: profile?.mobile
          },
          notes: {
            address: 'Soumya Dey Corporate Office'
          },
          theme: {
            color: '#61dafb'
          }
        }

        const paymentObject = new window.Razorpay(options)
        // const paymentObject = new window.Razorpay(options)
        paymentObject.open()
      }
    }
    return () => {
      previousProps.packagePurchasedData = packagePurchasedData
    }
  }, [packagePurchasedData])

  useEffect(() => {
    if (previousProps?.isPackagePurchaseFlag !== isPackagePurchaseFlag) {
      if (isPackagePurchaseFlag === true) {
        enqueueSnackbar(`${responseMessage}`, {
          variant: 'success',
          autoHide: true,
          hide: 3000
        })
        navigate('/center/purchase-license')
      } else if (isPackagePurchaseFlag === false) {
        enqueueSnackbar(`${responseMessage}`, {
          variant: 'error',
          autoHide: true,
          hide: 3000
        })
      }
    }
    return () => {
      previousProps.isPackagePurchaseFlag = isPackagePurchaseFlag
    }
  }, [isPackagePurchaseFlag])

  useEffect(() => {
    if (packageData) {
      const newarray = packageData.map((i) => {
        return {
          id: i.id,
          count: 1
        }
      })
      setCount(newarray)
    }
  }, [packageData])

  const decreaser = (id) => {
    setCount(
      count?.map((key) => {
        if (key.id === id) {
          return { ...key, count: key.count - 1 }
        }
        return key
      })
    )
  }
  const increaser = (id) => {
    // Counter state is incremented
    setCount(
      count?.map((key) => {
        if (key.id === id) {
          return { ...key, count: +key.count + 1 }
        }
        return key
      })
    )
  }

  console.log('count', count)
  function loadScript (src) {
    return new Promise((resolve) => {
      const script = document.createElement('script')
      script.src = src
      script.onload = () => {
        resolve(true)
      }
      script.onerror = () => {
        resolve(false)
      }
      document.body.appendChild(script)
    })
  }
  const handleActivePackage = async (id) => {
    console.log('id :>> ', id)
    const dataa = {
      packageId: id,
      total_packages: +count.find((key) => key.id === id).count
    }
    console.log('dataa :>> ', dataa)
    if (dataa) {
      dispatch(purchasePackageAction(dataa, token))
    }
    const res = await loadScript('https://checkout.razorpay.com/v1/checkout.js')

    if (!res) {
      alert('Razorpay SDK failed to load. Are you online?')
    }
  }
  return (
    <>
      <TitleHeader name='Credit' title='Purchase Credit' />
      <div className='cards'>
        <div className='row'>
          {packageData?.map((i) => {
            return (
              <>
                {/* <div key={i?.id}> */ }
                <div className='col-md-4 mb-3' key={i.id}>
                  <div className='package-card'>
                   <div>
                   <h5>{i?.title}</h5>
                    <div
                      className='desc-card'
                      dangerouslySetInnerHTML={{ __html: i?.description }}
                    ></div>
                   </div>
                    {console.log(
                      +count?.find((item) => item.id === i.id)?.count === 1
                    )}
                  <div>
                  <div className='counter'>
                      <button
                        onClick={() => decreaser(i.id)}
                        className='theme-btn'
                        disabled={
                          +count?.find((item) => item.id === i.id)?.count === 1
                        }
                      >
                        -
                      </button>
                      <Form.Group className='form-group' controlId='name'>
                        <Form.Control
                          type='number'
                          onChange={(e) =>
                            setCount(
                              count.map((key) => {
                                if (key.id === i.id) {
                                  return { ...key, count: e.target.value }
                                }
                                return key
                              })
                            )
                          }
                          value={count?.find((item) => item.id === i.id)?.count}
                        />
                      </Form.Group>
                      <button
                        onClick={() => increaser(i.id)}
                        className='theme-btn'
                      >
                        +
                      </button>
                    </div>
                    <div className='price-box'>
                      <h5>{i?.amount}/-RS</h5>
                      <p>(inclusive GST)</p>
                      <button
                        className='theme-btn'
                        onClick={() => handleActivePackage(i.id)}
                      >
                        Active Package Now
                      </button>
                    </div>
                  </div>
                  </div>
                </div>
                {/* </div> */}
              </>
            )
          })}
        </div>
      </div>
    </>
  )
}

export default PurchaseCredit
