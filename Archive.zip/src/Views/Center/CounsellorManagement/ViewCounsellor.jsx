import React, { useEffect } from 'react'

/* Components */
import TitleHeader from '../../../Components/TitleHeader'
import PdfIcon from '../../../assets/images/pdf-icon.svg'
import { Form } from 'react-bootstrap'
import { useDispatch, useSelector } from 'react-redux'
import { useNavigate, useParams } from 'react-router-dom'
import { getSpecificCounsellor } from '../../../Actions/Admin/counsellor'
import moment from 'moment'
import ls from 'localstorage-slim'
// import localStorage from 'react-secure-storage'

// import { Controller } from 'react-hook-form'
function ViewCounsellor () {
  // Constant
  const { id } = useParams()
  const dispatch = useDispatch()
  const token = localStorage.getItem('token')
  const navigate = useNavigate()
  // useSelector
  const mainData = useSelector(state => state.counsellorManAdmin.resData)
  const profile = JSON.parse(localStorage.getItem('profile'))
  const adminType = ls.get('admin-type', { decrypt: true, secret: profile?.id })

  useEffect(() => {
    if (adminType === 'super' || adminType === 'sub') {
      dispatch(getSpecificCounsellor(+id, token, 'admin'))
    } else {
      dispatch(getSpecificCounsellor(+id, token, 'center'))
    }
  }, [])

  return (
    <>
          {/* <Header /> */}
          <TitleHeader name='View' title='View Counsellor' />
          <div className='main-layout whitebox-layout my-editprofile-page'>
            <Form className='light-bg'>
            <div className="heading-box">
                  <h5>View Counsellor</h5>
                  <div className="btn-box">
                    <button className="theme-btn dark-btn text-none" onClick={(e) => {
                      navigate(-1)
                      e.preventDefault()
                    } }>
                      Cancel
                    </button>
                  </div>
                </div>
              <div className='light-bg-box'>
                <div className='row'>
                  <div className='col-xxl-9 '>
                    <div className='row'>
                      <div className='col-lg-12'>
                        <h4>Counsellor Details</h4>
                      </div>
                      <div className='col-lg-6'>
                        <Form.Group
                          className='form-group'
                          controlId='firstName'
                        >
                          <Form.Label>First Name</Form.Label>
                          <Form.Control
                            placeholder='Enter First Name'
                            type='text'
                            value={mainData?.counsellor?.first_name}
                            disabled
                          />
                        </Form.Group>
                      </div>
                      <div className='col-lg-6'>
                        <Form.Group
                          className='form-group'
                          controlId='firstName'
                        >
                          <Form.Label>Middle Name</Form.Label>
                          <Form.Control
                            placeholder='Enter Middle Name'
                            type='text'
                            value={mainData?.counsellor?.middle_name}
                            disabled
                          />
                        </Form.Group>
                      </div>
                      <div className='col-lg-6'>
                        <Form.Group className='form-group' controlId='lastName'>
                          <Form.Label>Last Name</Form.Label>
                          <Form.Control
                            placeholder='Enter Last Name'
                            type='text'
                            value={mainData?.counsellor?.last_name}
                            disabled
                          />
                        </Form.Group>
                      </div>
                      <div className='col-lg-6'>
                        <Form.Group className='form-group' controlId='formdate'>
                          <Form.Label>Date Of Birth</Form.Label>
                          <Form.Control name='dob' type='text' value={moment(mainData?.counsellor?.dob).format('DD-MM-YYYY')}
                            disabled />
                        </Form.Group>
                      </div>
                      <div className='col-lg-6'>
                        <Form.Group
                          controlId='formBasicEmail'
                          className='form-group'
                        >
                          <Form.Label>Mobile Number</Form.Label>
                          <Form.Control
                            placeholder='Enter Mobile Number'
                            type='text'
                            value={mainData?.counsellor?.mobile}
                            disabled
                          />
                        </Form.Group>
                      </div>
                      <div className='col-lg-6'>
                        <Form.Group
                          className='form-group verified'
                          controlId='formBasicEmail'
                        >
                          <Form.Label>Email ID</Form.Label>
                          <div className='position-relative'>
                            <Form.Control
                              placeholder='Enter Email ID'
                              type='email'
                              value={mainData?.counsellor?.email}
                              disabled
                            />
                          </div>
                        </Form.Group>
                      </div>
                      <div className='col-lg-6'>
                        <Form.Group
                          controlId='formBasicEmail'
                          className='form-group'
                        >
                          <Form.Label>Status</Form.Label>
                          <Form.Control
                            placeholder='Enter Mobile Number'
                            type='text'
                            value={mainData?.counsellor?.status}
                            disabled
                          />
                        </Form.Group>
                      </div>
                      <div className='col-lg-6'>
                        <Form.Group
                          className='form-group verified'
                          controlId='formBasicEmail'
                        >
                          <Form.Label>Commission (%)</Form.Label>
                          <div className='position-relative'>
                            <Form.Control
                              placeholder='Enter Email ID'
                              type='email'
                              value={mainData?.counsellor?.commission}
                              disabled
                            />
                          </div>
                        </Form.Group>
                      </div>
                      <div className='col-lg-12'>
                        <div className='row'>
                          <div className='col-md-6'>
                            <div className='row'>
                              <div className='col-xl-6'>
                              <Form.Group
                                  className="form-group common-select-style"
                                  controlId="formCountry"
                                >
                                  <Form.Label>Country</Form.Label>
                                  <Form.Control type="text" value={mainData?.counsellorDetail?.country?.title} disabled />
                                </Form.Group>
                              </div>
                              <div className='col-xl-6'>
                              <Form.Group
                                  className="form-group common-select-style"
                                  controlId="formState"
                                >
                                  <Form.Label>State</Form.Label>
                                  <Form.Control type="text" value={mainData?.counsellorDetail?.state?.title} disabled />
                                </Form.Group>
                              </div>
                            </div>
                          </div>
                          <div className='col-md-6'>
                            <div className='row'>
                              <div className='col-xl-6'>
                              <Form.Group
                                  className="form-group common-select-style"
                                  controlId="formDistrict"
                                >
                                  <Form.Label>District</Form.Label>
                                  <Form.Control type="text" value={mainData?.counsellorDetail?.city?.title} disabled />
                                </Form.Group>
                              </div>
                              <div className='col-xl-6'>
                                <Form.Group
                                  className='form-group'
                                  controlId='formpincode1'
                                >
                                  <Form.Label>PIN Code</Form.Label>
                                  <Form.Control type='text' value={mainData?.counsellorDetail?.pin_code} disabled />
                                </Form.Group>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className='col-lg-6'>
                        <Form.Group
                          className='form-group common-select-style'
                          controlId='formfullname'
                        >
                          <Form.Label>Professional Expertness</Form.Label>
                          <Form.Control type='text' value={mainData?.counsellorDetail?.professional_expertnesses
                            ?.title} disabled />
                        </Form.Group>
                      </div>
                      <div className='col-lg-6'>
                        {mainData?.counsellorDetail?.resume &&
                      <Form.Group
                        controlId='formFile'
                        className='form-group resume-file-input'
                      >
                        <Form.Label>File</Form.Label>
                        <div>
                          <a
                            href={`${process.env.REACT_APP_AXIOS_BASE_URL}${mainData?.counsellorDetail?.resume}`}
                            target='_blank'
                            rel='noreferrer'
                          >
                            <img src={PdfIcon} alt='ollato-img' />
                            {'    '}Resume
                          </a>
                        </div>
                      </Form.Group>}
                      </div>
                      <div className="col-lg-12 rowspacer">
                    <div className="p-3">
                      <div className="row">
                            <Form.Group
                            controlId='formgstnumber'
                            className='form-group document-file-input common-input-file  uploaded-doc counsellor-checkbox'
                          >
                            <Form.Label>Types :</Form.Label>
                            <Form.Check
                            type='checkbox'
                          >
                            <Form.Check.Input
                              checked={mainData?.counsellor?.career_counsellor === '1'}
                              disabled
                            />
                              <Form.Check.Label>
                                 Career Counsellor
                              </Form.Check.Label>
                              </Form.Check>
                              <Form.Check
                                type='checkbox'
                              >
                                <Form.Check.Input
                                  name='is_math'
                                  type='checkbox'
                                  checked={mainData?.counsellor?.psychologist === '1'}
                                  disabled
                                />
                              <Form.Check.Label>
                                 Psychologist
                              </Form.Check.Label>
                            </Form.Check>
                            <Form.Check
                              type='checkbox'
                            >
                              <Form.Check.Input
                                type='checkbox'
                                name='is_correct_ans'
                                checked={mainData?.counsellor?.overseas_counsellor === '1'}
                                disabled
                              />
                                <Form.Check.Label>
                                  Overseas Counsellor
                                </Form.Check.Label>
                                </Form.Check>
                                <Form.Check
                              type='checkbox'
                            >
                              <Form.Check.Input
                                type='checkbox'
                                name='is_correct_ans'
                                checked={mainData?.counsellor?.subject_expert ===
                                  '1'}
                                disabled
                              />
                                <Form.Check.Label>
                                  Subject Expert
                                </Form.Check.Label>
                                </Form.Check>
                          </Form.Group>
                          {/* </div> */}

                      </div>
                    </div>
                  </div>
                    </div>
                  </div>
                </div>
              </div>
            </Form>
          </div>
    </>
  )
}

export default ViewCounsellor
