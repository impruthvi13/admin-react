import React, { useState, useEffect, useRef } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { useLocation, useNavigate } from 'react-router-dom'
import { Button, Form } from 'react-bootstrap'
import Select from 'react-select'
import { useForm, Controller } from 'react-hook-form'
import * as yup from 'yup'
import { yupResolver } from '@hookform/resolvers/yup'
import moment from 'moment'
import { useSnackbar } from 'react-notistack'

/* Components */
import TitleHeader from '../../../Components/TitleHeader'
import crossWhite from '../../../assets/images/crosswhite.svg'
import otherdocPlaceholder from '../../../assets/images/other-img-placeholder.svg'
// import pancard from '../../../assets/images/pancard-img.png'
import defaultPic from '../../../assets/images/default_profile.jpg'
// import sign from '../../../assets/images/sign.svg'

// import { Controller } from 'react-hook-form'
// import profilePlaceholder from '../../../assets/images/profile-placeholder.svg'

import { useAddress } from '../../../Shared/Hooks/UseAddress'

// Action Files
import { getCounsellorDataAction, editCounsellorProfileAction } from '../../../Actions/Counsellor/dashboard'
import {
  GetAllUniversityData,
  GetQualificationAction
} from '../../../Actions/auth'

// Regex
const phoneRegex = /^(\+\d{1,3}[- ]?)?\d{10}$/
const emailRegex = /.+@.+\.[A-Za-z]+$/
const panCard = /([A-Z]){5}([0-9]){4}([A-Z]){1}$/
const aadharCard = /^[2-9]{1}[0-9]{3}\s{1}[0-9]{4}\s{1}[0-9]{4}$/
const gstNo = /^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$/

const validationSchema = yup.object().shape({
  files: yup.mixed().test('required', 'Please select a file', (value) => {
    return value && value.length
  }),
  firstName: yup.string().required('First Name is required'),
  middleName: yup.string().required('Middle Name is required'),
  lastName: yup.string().required('Last Name is required'),
  dob: yup.string().required('Date of Birth is required'),
  mobileNumber: yup
    .string()
    .required('Mobile Number is required')
    .matches(phoneRegex, 'Enter valid Mobile Number'),
  email: yup
    .string()
    .required('Email is required')
    .matches(emailRegex, 'Enter valid E-Mail'),
  country: yup
    .object()
    .shape({
      id: yup.string().required('Country is required'),
      title: yup.string().required('Country is required')
    })
    .nullable() // for handling null value when clearing options via clicking "x"
    .required('Country is required'),
  district: yup
    .object()
    .shape({
      title: yup.string().required('District is required'),
      id: yup.string().required('District is required')
    })
    .nullable() // for handling null id when clearing options via clicking "x"
    .required('District is required'),
  state: yup
    .object()
    .shape({
      title: yup.string().required('State is required'),
      id: yup.string().required('State is required')
    })
    .nullable() // for handling null id when clearing options via clicking "x"
    .required('State is required'),
  pincode: yup.string().required('Pincode is required'),
  year: yup
    .object()
    .shape({
      label: yup.string().required('Year is required'),
      value: yup.string().required('Year is required')
    })
    .nullable() // for handling null value when clearing options via clicking "x"
    .required('Year is required'),
  month: yup
    .object()
    .shape({
      label: yup.string().required('Month is required'),
      value: yup.string().required('Month is required')
    })
    .nullable() // for handling null value when clearing options via clicking "x"
    .required('Year is required'),
  panNo: yup
    .string()
    .required('PanCard number is required')
    .nullable() // for handling null id when clearing options via clicking "x"
    .matches(panCard, 'Please enter valid pancard number'),
  aadharNo: yup
    .string()
    .nullable() // for handling null id when clearing options via clicking "x"
    .required('AadharCard number is required').matches(aadharCard, 'Please enter valid aadhar number'),
  gstNo: yup
    .string()
    .nullable() // for handling null id when clearing options via clicking "x"
    .required('GST number is required').matches(gstNo, 'Please enter valid GST number'),
  university: yup
    .object()
    .shape({
      title: yup.string().required('University is required'),
      id: yup.string().required('University is required')
    })
    .nullable() // for handling null id when clearing options via clicking "x"
    .required('University is required'),
  lQualification: yup
    .object()
    .shape({
      title: yup.string().required('Last Qualification is required'),
      id: yup.string().required('Last Qualification is required')
    })
    .nullable() // for handling null id when clearing options via clicking "x"
    .required('Last Qualification is required'),
  universityLast: yup
    .object()
    .shape({
      title: yup.string().required('University is required'),
      id: yup.string().required('University is required')
    })
    .nullable() // for handling null id when clearing options via clicking "x"
    .required('University is required'),
  certificate: yup
    .object()
    .shape({
      title: yup.string().required('Certificate is required'),
      id: yup.string().required('Certificate is required')
    })
    .nullable() // for handling null id when clearing options via clicking "x"
    .required('Certificate is required'),
  certificateQua: yup
    .object()
    .shape({
      title: yup.string().required('University is required'),
      id: yup.string().required('University is required')
    })
    .nullable() // for handling null id when clearing options via clicking "x"
    .required('University is required'),
  panCardFiles: yup
    .mixed()
    .required('File is required')
    .test('required', 'Please select a file', (value) => {
      console.log('v____', value.length)
      return value && value.length
    })
})

function Editmyprofile () {
  const location = useLocation()
  const dispatch = useDispatch()
  const navigate = useNavigate()
  const { enqueueSnackbar } = useSnackbar()

  const token = localStorage.getItem('token')

  // useState
  const [data, setData] = useState({})
  const [selectedImage, setSelectedFile] = useState()
  const [selectedResume, setSelectedResume] = useState()
  const [selectedPanCard, setPanCardImage] = useState()
  const [selectedACardFront, setACardFront] = useState()
  const [selectedACardBack, setACardBack] = useState()
  const [signature, setSignature] = useState()
  const [careerChecked, setCareerChecked] = useState(false)
  const [psyChecked, setPsyChecked] = useState(false)
  const [overChecked, setOverChecked] = useState(false)
  const [studentExpert, setStudentExpert] = useState(false)

  // useSelector
  const profileData = useSelector((state) => state.dashboard.counsellorData)
  // const countriesArray = useSelector((state) => state.auth.countriesData)
  // const districtArray = useSelector((state) => state.auth.districtData)
  // const statesArray = useSelector((state) => state.auth.statesData)
  const universityData = useSelector((state) => state.auth.universityData)
  const qualificationData = useSelector((state) => state.auth.qData)
  const isProfileUpdatedFlag = useSelector((state) => state.dashboard.isProfileUpdated)
  const resMessageFlag = useSelector((state) => state.dashboard.resMessage)

  console.log('isProfileUpdatedFlag', qualificationData)

  const previousProps = useRef({
    profileData,
    // districtArray,
    // countriesArray,
    // statesArray,
    universityData,
    qualificationData,
    isProfileUpdatedFlag,
    resMessageFlag
  }).current

  console.log('profileData------ :>> ', profileData)

  useEffect(() => {
    if (location?.state?.id?.id) {
      dispatch(getCounsellorDataAction(token))
    }
  }, [location?.state?.id?.id])

  // useForm
  const {
    control,
    register,
    handleSubmit,
    setValue,
    getValues,
    reset,
    formState: { errors }
  } = useForm({
    resolver: yupResolver(validationSchema)
  })
  const { onChange } = register()

  const { setCountryid, setStateid, countriesArray, statesArray, districtArray } = useAddress()

  useEffect(() => {
    dispatch(GetAllUniversityData(token))
    dispatch(GetQualificationAction(token))
  }, [])

  useEffect(() => {
    if (previousProps?.profileData !== profileData) {
      if (profileData) {
        setData(profileData)
      }
    }
    return () => {
      previousProps.profileData = profileData
    }
  }, [profileData])

  useEffect(() => {
    if (data) {
      setCountryid(data?.details?.country?.id)
      setStateid(data?.details?.state?.id)
      setPanCardImage(data?.details?.pan_file)
      setACardFront(data?.details?.adhar_card_number_front)
      setACardBack(data?.details?.adhar_card_number_back)
      setSignature(data?.details?.signature)
      setCareerChecked(data?.career_counsellor === '1')
      setPsyChecked(data?.psychologist === '1')
      setOverChecked(data?.overseas_counsellor === '1')
      setStudentExpert(data?.subject_expert === '1')

      reset({
        files: data?.details?.profile_picture,
        resumefiles: data?.resume,
        panCardFiles: `${process.env.REACT_APP_AXIOS_BASE_URL}${data?.details?.pan_file}`,
        firstName: data.first_name,
        lastName: data.last_name,
        middleName: data.middle_name,
        dob: moment(data.dob).format('YYYY-MM-DD'),
        mobileNumber: data.mobile,
        email: data.email,
        pincode: data?.details?.pin_code,
        panNo: data?.details?.pan_number,
        aadharNo: data?.details?.adhar_card_number,
        gstNo: data?.details?.gst_no,
        country: {
          id: data?.details?.country?.id,
          title: data?.details?.country?.title
        },
        district: {
          id: data?.details?.city?.id,
          title: data?.details?.city?.title
        },
        state: {
          id: data?.details?.state?.id,
          title: data?.details?.state?.title
        },
        year: year?.find((s) => Number(s.value) === data?.details?.experience_year),
        month: month?.find((s) => Number(s.value) === data?.details?.experience_month),
        university: {
          id: data?.details?.universities?.id,
          title: data?.details?.universities?.title
        },
        lQualification: {
          id: data?.details?.qualifications?.id,
          title: data?.details?.qualifications?.title
        },
        hQualification: {
          id: data?.details?.qualifications?.id,
          title: data?.details?.qualifications?.title
        },
        universityLast: {
          id: data?.details?.universities?.id,
          title: data?.details?.universities?.title
        },
        certificate: {
          id: data?.details?.qualifications?.id,
          title: data?.details?.qualifications?.title
        },
        certificateQua: {
          id: data?.details?.universities?.id,
          title: data?.details?.universities?.title
        }
      })
    }
  }, [data,
    universityData,
    qualificationData])

  /* for Year */
  const year = [
    { value: '2010', label: '2010' },
    { value: '2011', label: '2011' },
    { value: '2012', label: '2012' },
    { value: '2013', label: '2013' },
    { value: '2014', label: '2014' },
    { value: '2015', label: '2015' },
    { value: '2016', label: '2016' },
    { value: '2017', label: '2017' },
    { value: '2018', label: '2018' },
    { value: '2019', label: '2019' }
  ]

  /* for month */
  const month = [
    { value: '1', label: '1' },
    { value: '2', label: '2' },
    { value: '3', label: '3' },
    { value: '4', label: '4' },
    { value: '5', label: '5' },
    { value: '6', label: '6' },
    { value: '7', label: '7' },
    { value: '8', label: '8' },
    { value: '9', label: '9' },
    { value: '10', label: '10' },
    { value: '11', label: '11' },
    { value: '12', label: '12' }
  ]

  console.log('selectedImage :>> ', selectedImage)

  const onSubmit = (data) => {
    console.log('data', data)
    console.log('d---ata', selectedResume)
    if (careerChecked === false && psyChecked === false && overChecked === false && studentExpert === false) {
      return null
    } else {
      const formData = new FormData()
      // formData.append('counsellor_id', location?.state?.id?.counsellor_id)
      formData.append('first_name', data?.firstName)
      formData.append('middle_name', data?.middleName)
      formData.append('last_name', data?.lastName)
      formData.append('mobile', data?.mobileNumber)
      formData.append('email', data?.email)
      formData.append('dob', data?.dob)
      formData.append('country_id', data?.country?.id)
      formData.append('state_id', data?.state?.id)
      formData.append('city_id', data?.district?.id)
      formData.append('pin_code', data?.pincode)
      formData.append('professional_expertness_id', '')
      formData.append('resume', data?.resumefiles)
      formData.append('experience_year', data?.year?.value)
      formData.append('experience_month', data?.month?.value)
      formData.append('high_qualification_id', Number(data?.hQualification?.id))
      formData.append('high_university_id', Number(data?.university?.id))
      formData.append('last_qualification_id', Number(data?.lQualification?.id))
      formData.append('last_university_id', Number(data?.universityLast?.id))
      formData.append('certificate_qualification_id', Number(data?.certificateQua?.id))
      formData.append('certificate_university_id', Number(data?.certificate?.id))
      formData.append('pan_number', data?.panNo)
      formData.append('adhar_card_number', data?.aadharNo)
      formData.append('gst_no', data?.gstNo)
      formData.append('adharcard_front', selectedACardFront)
      formData.append('adharcard_back', selectedACardBack)
      formData.append('pancard', selectedPanCard)
      formData.append('profile_picture', selectedImage)
      formData.append('signature', signature)
      formData.append('career_counsellor', careerChecked === true ? '1' : '0')
      formData.append('psychologist', psyChecked === true ? '1' : '0')
      formData.append('overseas_counsellor', overChecked === true ? '1' : '0')
      formData.append('subject_expert', studentExpert === true ? '1' : '0')
      if (formData) {
        dispatch(editCounsellorProfileAction(formData, token))
      }
    }
  }

  const handleImageClose = (e, type) => {
    console.log('hello')
    e.preventDefault()
    switch (type) {
      case 'panCardFile':
        return setPanCardImage()
      case 'frontAdharCard':
        return setACardFront()
      case 'backAdharCard':
        return setACardBack()
      case 'signature':
        return setSignature()
      default:
        return null
    }
  }

  // Toastify Notification
  useEffect(() => {
    if (previousProps?.isProfileUpdatedFlag !== isProfileUpdatedFlag) {
      if (isProfileUpdatedFlag === true) {
        enqueueSnackbar(`${resMessageFlag}`, {
          variant: 'success',
          autoHide: true,
          hide: 3000
        })
        navigate('/counsellor/profile')
      } else if (isProfileUpdatedFlag === false) {
        enqueueSnackbar(`${resMessageFlag}`, {
          variant: 'error',
          autoHide: true,
          hide: 3000
        })
      }
    }
    return () => {
      previousProps.isProfileUpdatedFlag = isProfileUpdatedFlag
    }
  }, [isProfileUpdatedFlag])

  return (
    <>
        {/* <div className='main-content-box'> */}
          {/* <Header /> */}
          <TitleHeader name='Edit' title='My Profile' />
          <div className='main-layout whitebox-layout my-editprofile-page'>
            <Form onSubmit={handleSubmit(onSubmit)}>
              <div className='profilebutton-box text-end'>
                <Button
                  className='theme-btn text-none d-inline-block'
                  type='submit'
                >
                  Save
                </Button>
              </div>
              <div className='light-bg-box'>
                <div className='row'>
                  <div className='col-xxl-3 profile-update'>
                    <Form.Group
                      controlId='formFile'
                      className='form-group profile-picture  common-input-file '
                    >
                      <Form.Control
                        type='file'
                        className='hidden-file'
                        name='files'
                        {...register('files', { required: true })}
                        onChange={(e) => {
                          onChange(e)
                          setSelectedFile(e.target.files[0])
                        }}
                      />
                    <div className="img-box">
                    <div className='form-control d-flex align-items-center flex-column justify-content-center text-center '>
                        {selectedImage
                          ? (
                          <>
                            <img
                              src={ selectedImage !== null ? URL.createObjectURL(selectedImage) : ''}
                              alt=''
                            />
                            {/* <p className='m-0 blue-placeholder'>
                                Upload Profile Photo
                              </p> */}
                          </>
                            )
                          : (
                          <>
                            <img
                              src={data?.details?.profile_picture === null || data?.details?.profile_picture === 'undefined' ? defaultPic : `${process.env.REACT_APP_AXIOS_BASE_URL}${data?.details?.profile_picture}`}
                              alt=''
                            />
                          </>
                            )}
                      </div>
                    </div>
                    </Form.Group>
                    <p className='error-msg'>
                      {errors.files?.message || errors.files?.label.message}
                    </p>
                  </div>
                  <div className='col-xxl-9 '>
                    <div className='row'>
                      <div className='col-lg-12'>
                        <h4>Counsellor Details</h4>
                      </div>
                      <div className='col-lg-6'>
                        <Form.Group
                          className={`form-group ${
                            errors.firstName?.message ? 'error-occured' : ''
                          }`}
                          controlId='formfirstname'
                        >
                          <Form.Label>First Name</Form.Label>
                          <Form.Control
                            type='text'
                            {...register('firstName', { required: true })}
                          />
                          {errors.firstName?.message && (
                            <Form.Text className='error-msg'>
                              {errors.firstName?.message}{' '}
                            </Form.Text>
                          )}
                        </Form.Group>
                      </div>
                      <div className='col-lg-6'>
                        <Form.Group
                          className={`form-group ${
                            errors.middleName?.message ? 'error-occured' : ''
                          }`}
                          controlId='formmiddlename'
                        >
                          <Form.Label>Middle Name</Form.Label>
                          <Form.Control
                            type='text'
                            {...register('middleName', { required: true })}
                          />
                          {errors.middleName?.message && (
                            <Form.Text className='error-msg'>
                              {errors.middleName?.message}{' '}
                            </Form.Text>
                          )}
                        </Form.Group>
                      </div>
                      <div className='col-lg-6'>
                        <Form.Group
                          className={`form-group ${
                            errors.lastName?.message ? 'error-occured' : ''
                          }`}
                          controlId='formlastname'
                        >
                          <Form.Label>Last Name</Form.Label>
                          <Form.Control
                            type='text'
                            {...register('lastName', { required: true })}
                          />
                          {errors.lastName?.message && (
                            <Form.Text className='error-msg'>
                              {errors.lastName?.message}{' '}
                            </Form.Text>
                          )}
                        </Form.Group>
                      </div>
                      <div className='col-lg-6'>
                        <Form.Group
                          className={`form-group ${
                            errors.dob?.message ? 'error-occured' : ''
                          }`}
                          controlId='formdate'
                        >
                          <Form.Label>Date Of Birth</Form.Label>
                          {/* <Form.Control type="date" value="23/12/2022" /> */}
                          <Controller
                            control={control}
                            name='dob'
                            render={(props) => (
                              <Form.Control
                                type='date'
                                max={new Date().toISOString().slice(0, 10)}
                                name={name}
                                onChange={(e) => {
                                  onChange(e)
                                  setValue('dob', e.target.value)
                                }}
                                {...register('dob', { required: true })}
                              />
                            )}
                          />
                          {errors.dob?.message && (
                            <Form.Text className='error-msg'>
                              {errors.dob?.message}{' '}
                            </Form.Text>
                          )}
                        </Form.Group>
                      </div>
                      <div className='col-lg-6'>
                        <Form.Group
                          className={`form-group ${
                            errors.mobileNumber?.message ? 'error-occured' : ''
                          }`}
                          controlId='formBasicmobile'
                        >
                          <Form.Label>Mobile Number</Form.Label>
                          <div className='position-relative'>
                            <Form.Control
                              type='text'
                              {...register('mobileNumber', { required: true })}
                            />
                          </div>
                          {errors.mobileNumber?.message && (
                            <Form.Text className='error-msg'>
                              {errors.mobileNumber?.message}{' '}
                            </Form.Text>
                          )}
                        </Form.Group>
                      </div>
                      <div className='col-lg-6'>
                        <Form.Group
                          className={`form-group ${
                            errors.email?.message ? 'error-occured' : ''
                          }`}
                          controlId='formBasicEmail'
                        >
                          <Form.Label>Email ID</Form.Label>
                          <div className='position-relative'>
                            <Form.Control
                              type='text'
                              {...register('email', { required: true })}
                            />
                          </div>
                          {errors.email?.message && (
                            <Form.Text className='error-msg'>
                              {errors.email?.message}{' '}
                            </Form.Text>
                          )}
                        </Form.Group>
                      </div>
                      <div className='col-lg-12'>
                        <div className='row'>
                          <div className='col-md-6'>
                            <div className='row'>
                              <div className='col-xl-6'>
                                <Form.Group
                                  className='form-group common-select-style'
                                  controlId='formfullname'
                                >
                                  <Form.Label>Country</Form.Label>
                                  <Controller
                                    name='country'
                                    control={control}
                                    render={({
                                      field: { onChange, value = {} }
                                    }) => {
                                      return (
                                        <Select
                                          placeholder={'Select Country'}
                                          className='react-dropdown'
                                          classNamePrefix='dropdown'
                                          options={countriesArray}
                                          getOptionLabel={(option) =>
                                            option?.title
                                          }
                                          getOptionValue={(option) =>
                                            option?.id
                                          }
                                          value={value || getValues().country}
                                          onChange={(e) => {
                                            onChange(e)
                                            setCountryid(e.id)
                                          }}
                                        />
                                      )
                                    }}
                                  />
                                  <p className='error-msg'>
                                    {errors.country?.message ||
                                      errors.country?.title.message}
                                  </p>
                                </Form.Group>
                              </div>
                              <div className='col-xl-6'>
                                <Form.Group
                                  className='form-group common-select-style'
                                  controlId='formfullname'
                                >
                                  <Form.Label>State</Form.Label>
                                  <Controller
                                    name='state'
                                    control={control}
                                    render={({ field }) => {
                                      return (
                                        <Select
                                          placeholder={'Select State'}
                                          className='react-dropdown'
                                          classNamePrefix='dropdown'
                                          options={statesArray}
                                          getOptionLabel={(option) => option?.title}
                                          getOptionValue={(option) => option?.id}
                                          value={field.value || getValues().state}
                                          onChange={(e) => {
                                            field.onChange(e)
                                            setStateid(e.id)
                                            setValue('district', '')
                                          }}
                                        />
                                      )
                                    }}
                                  />

                                </Form.Group>
                                <p className='error-msg'>
                                  {errors.state?.message ||
                                    errors.state?.title.message}
                                </p>
                              </div>
                            </div>
                          </div>
                          <div className='col-md-6'>
                            <div className='row'>
                              <div className='col-xl-6'>
                                <Form.Group
                                  className='form-group common-select-style'
                                  controlId='formfullname'
                                >
                                  <Form.Label>District</Form.Label>
                                  <Controller
                                    name='district'
                                    control={control}
                                    render={({ field }) => {
                                      return (
                                        <Select
                                          {...field}
                                          placeholder={'Select District'}
                                          className='react-dropdown'
                                          classNamePrefix='dropdown'
                                          options={districtArray}
                                          getOptionLabel={(option) =>
                                            option?.title
                                          }
                                          getOptionValue={(option) =>
                                            option?.id
                                          }
                                        />
                                      )
                                    }}
                                  />
                                </Form.Group>
                                <p className='error-msg'>
                                  {errors.district?.message ||
                                    errors.district?.title.message}
                                </p>
                              </div>
                              <div className='col-xl-6'>
                                <Form.Group
                                  className={`form-group ${
                                    errors.pincode?.message
                                      ? 'error-occured'
                                      : ''
                                  }`}
                                  controlId='formpincode1'
                                >
                                  <Form.Label>PIN Code</Form.Label>
                                  <Form.Control
                                    type='number'
                                    {...register('pincode', { required: true })}
                                  />
                                  {errors.pincode?.message && (
                                    <Form.Text className='error-msg'>
                                      {errors.pincode?.message}{' '}
                                    </Form.Text>
                                  )}
                                </Form.Group>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className='col-lg-6'>
                        <Form.Group
                          className='form-group common-select-style'
                          controlId='formfullname'
                        >
                          <Form.Label>Professional Expertness</Form.Label>
                          <Select
                            placeholder={'Select from the list '}
                            className='react-dropdown'
                            classNamePrefix='dropdown'
                          />
                        </Form.Group>
                      </div>
                      <div className='col-lg-6'>
                        <Form.Group
                          controlId='formFile'
                          className='form-group resume-file-input'
                        >
                          <Form.Label>Resume</Form.Label>
                          <Form.Control
                            type='file'
                            title='Upload Resume'
                            className='hidden-file'
                            name='resumefiles'
                            {...register('resumefiles', { required: true })}
                            accept='application/pdf,application/msword'
                            onChange={(e) => {
                              onChange(e)
                              setSelectedResume(e.target.files[0])
                            }}
                            // disabled
                          />
                          <div className='form-control d-flex justify-content-between align-items-center'>
                            <a
                              href={`${process.env.REACT_APP_AXIOS_BASE_URL}${profileData?.resume}`}
                              target='__blank'
                            >
                              {/* <img src={pdficon} alt="ollato-img" /> */}
                              {/* <h4>{filename}</h4> */}
                              <h4>Resume</h4>
                            </a>
                            <button className='browse-btn'>Browse</button>
                          </div>
                          <p className='error-msg'></p>
                        </Form.Group>
                      </div>
                      <div className='col-lg-12'>
                        <h4>Experience Details</h4>
                      </div>
                      <div className='col-lg-12'>
                        <div className='row'>
                          <div className='col-md-6'>
                            <div className='row'>
                              <div className='col-xl-6'>
                                <Form.Group
                                  className='form-group common-select-style'
                                  controlId='formfullname'
                                >
                                  <Form.Label>Year</Form.Label>
                                  {/* <Select isSearchable={true} Value={selectedYear} onChange={setSelectedYear} options={year} placeholder={'Select Year'}/> */}
                                  <Controller
                                    name='year'
                                    control={control}
                                    render={({ field }) => (
                                      <Select
                                        // defaultValue={options[0]}
                                        {...field}
                                        isClearable // enable isClearable to demonstrate extra error handling
                                        isSearchable={false}
                                        // Value={selectedState}
                                        placeholder={'Select Year'}
                                        className='react-dropdown'
                                        classNamePrefix='dropdown'
                                        options={year}
                                      />
                                    )}
                                  />
                                  <p className='error-msg'>
                                    {errors.year?.message ||
                                      errors.year?.label.message}
                                  </p>
                                </Form.Group>
                              </div>
                              <div className='col-xl-6'>
                                <Form.Group
                                  className='form-group common-select-style'
                                  controlId='formfullname'
                                >
                                  <Form.Label>Month</Form.Label>
                                  {/* <Select isSearchable={true} Value={selectedMonth} onChange={setSelectedMonth} options={month} placeholder={'Select Month'}/> */}
                                  <Controller
                                    name='month'
                                    control={control}
                                    render={({ field }) => (
                                      <Select
                                        // defaultValue={options[0]}
                                        {...field}
                                        isClearable // enable isClearable to demonstrate extra error handling
                                        isSearchable={false}
                                        // Value={selectedState}
                                        placeholder={'Select Year'}
                                        className='react-dropdown'
                                        classNamePrefix='dropdown'
                                        options={month}
                                      />
                                    )}
                                  />
                                  <p className='error-msg'>
                                    {errors.month?.message ||
                                      errors.month?.label.message}
                                  </p>
                                </Form.Group>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className='row'>
                        <div className='col-lg-12'>
                          <h4>Counsellor Details</h4>
                        </div>
                        <div className='col-lg-6'>
                          <Form.Group
                            className='form-group common-select-style'
                            controlId='HighestQualification '
                          >
                            <Form.Label> Pan card number</Form.Label>
                            <Form.Control
                              type='text'
                              {...register('panNo', { required: true })}
                            />
                            {errors.panNo?.message && (
                              <Form.Text className='error-msg'>
                                {errors.panNo?.message}{' '}
                              </Form.Text>
                            )}
                          </Form.Group>
                        </div>
                        <div className='col-lg-6'>
                          <Form.Group className={`form-group ${errors.aadharNo?.message ? 'error-occured' : ''}`} controlId="formaadharcardnumber">
                          <Form.Label>Aadhar Card Number</Form.Label>
                          <Form.Control
                            type="text"
                            placeholder="Enter Aadhar Card Number"
                            name={name}
                            onChange={(e) => { onChange(e) }}
                            {...register('aadharNo', { required: true })}
                          />
                          <p className="error-msg">{errors.aadharNo?.message || errors.aadharNo?.label.message}</p>
                        </Form.Group>
                        </div>
                        <div className='col-lg-6'>
                          <Form.Group className={`form-group ${errors.gstNo?.message ? 'error-occured' : ''}`} controlId="formgstnumber">
                          <Form.Label>GST No</Form.Label>
                          <Form.Control
                              type="text"
                              placeholder="Enter GST No"
                              name={name}
                              onChange={(e) => { onChange(e) }}
                              {...register('gstNo', { required: true })}
                          />
                        <p className="error-msg">{errors.gstNo?.message || errors.gstNo?.label.message}</p>
                        </Form.Group>
                        </div>
                        <div className='col-lg-6'>
                          <Form.Group
                            className='form-group common-select-style'
                            controlId='HighestQualification '
                          >
                            <Form.Label>High Qualification</Form.Label>
                            <Controller
                              name='hQualification'
                              control={control}
                              render={({ field: { onChange, value = {} } }) => (
                                <Select
                                  isClearable
                                  isSearchable={false}
                                  placeholder={'Select High Qualification'}
                                  className='react-dropdown'
                                  classNamePrefix='dropdown'
                                  options={qualificationData}
                                  getOptionLabel={(option) => option?.title}
                                  getOptionValue={(option) => option?.id}
                                  value={value || getValues().hQualification}
                                  onChange={(e) => {
                                    onChange(e)
                                  }}
                                />
                              )}
                            />
                          </Form.Group>
                          <p className='error-msg'>
                            {errors.hQualification?.message ||
                              errors.hQualification?.label.message}
                          </p>
                        </div>
                        <div className='col-lg-6'>
                          <Form.Group
                            className='form-group common-select-style'
                            controlId='UniversityInstitution'
                          >
                            <Form.Label>University/Institution</Form.Label>
                            <Controller
                              name='university'
                              control={control}
                              render={({ field: { onChange, value = {} } }) => (
                                <Select
                                  isClearable
                                  isSearchable={false}
                                  placeholder={'Select University'}
                                  className='react-dropdown'
                                  classNamePrefix='dropdown'
                                  options={universityData}
                                  getOptionLabel={(option) => option?.title}
                                  getOptionValue={(option) => option?.id}
                                  value={value || getValues().university}
                                  onChange={(e) => {
                                    onChange(e)
                                  }}
                                />
                              )}
                            />
                            <p className='error-msg'>
                              {errors.university?.message ||
                                errors.university?.title?.message}
                            </p>
                          </Form.Group>
                        </div>
                        <div className='col-lg-6'>
                          <Form.Group
                            className='form-group common-select-style'
                            controlId='HighestQualification '
                          >
                            <Form.Label>Last Qualification</Form.Label>
                            <Controller
                              name='lQualification'
                              control={control}
                              render={({ field: { onChange, value = {} } }) => (
                                <Select
                                  isClearable
                                  isSearchable={false}
                                  placeholder={'Select Last Qualification'}
                                  className='react-dropdown'
                                  classNamePrefix='dropdown'
                                  options={qualificationData}
                                  getOptionLabel={(option) => option?.title}
                                  getOptionValue={(option) => option?.id}
                                  value={value || getValues().lQualification}
                                  onChange={(e) => {
                                    onChange(e)
                                  }}
                                />
                              )}
                            />
                          </Form.Group>
                          <p className='error-msg'>
                            {errors.lQualification?.message ||
                              errors.lQualification?.title.message}
                          </p>
                        </div>
                        <div className='col-lg-6'>
                          <Form.Group
                            className='form-group common-select-style'
                            controlId='UniversityInstitution'
                          >
                            <Form.Label>University/Institution</Form.Label>
                            <Controller
                              name='universityLast'
                              control={control}
                              render={({ field: { onChange, value = {} } }) => (
                                <Select
                                  isClearable
                                  isSearchable={false}
                                  placeholder={'Select University'}
                                  className='react-dropdown'
                                  classNamePrefix='dropdown'
                                  options={universityData}
                                  getOptionLabel={(option) => option?.title}
                                  getOptionValue={(option) => option?.id}
                                  value={value || getValues().universityLast}
                                  onChange={(e) => {
                                    onChange(e)
                                  }}
                                />
                              )}
                            />
                            <p className='error-msg'>
                              {errors.universityLast?.message ||
                                errors.universityLast?.title.message}
                            </p>
                          </Form.Group>
                        </div>
                        <div className='col-lg-6'>
                          <Form.Group
                            className='form-group common-select-style'
                            controlId='HighestQualification '
                          >
                            <Form.Label>Certification</Form.Label>
                            <Controller
                              name='certificate'
                              control={control}
                              render={({ field: { onChange, value = {} } }) => (
                                <Select
                                  isClearable
                                  isSearchable={false}
                                  placeholder={'Select Certificate'}
                                  className='react-dropdown'
                                  classNamePrefix='dropdown'
                                  options={qualificationData}
                                  getOptionLabel={(option) => option?.title}
                                  getOptionValue={(option) => option?.id}
                                  value={value || getValues().certificate}
                                  onChange={(e) => {
                                    onChange(e)
                                  }}
                                />
                              )}
                            />
                          </Form.Group>
                          <p className='error-msg'>
                            {errors.certificate?.message ||
                              errors.certificate?.title.message}
                          </p>
                        </div>
                        <div className='col-lg-6'>
                          <Form.Group
                            className='form-group common-select-style'
                            controlId='UniversityInstitution1'
                          >
                            <Form.Label>University/Institution</Form.Label>
                            <Controller
                              name='certificateQua'
                              control={control}
                              render={({ field: { onChange, value = {} } }) => (
                                <Select
                                  isClearable
                                  isSearchable={false}
                                  placeholder={'Select University'}
                                  className='react-dropdown'
                                  classNamePrefix='dropdown'
                                  options={universityData}
                                  getOptionLabel={(option) => option?.title}
                                  getOptionValue={(option) => option?.id}
                                  value={value || getValues().certificateQua}
                                  onChange={(e) => {
                                    onChange(e)
                                  }}
                                />
                              )}
                            />
                          </Form.Group>
                          <p className='error-msg'>
                            {errors.certificateQua?.message ||
                              errors.certificateQua?.title.message}
                          </p>
                        </div>
                        <div className='col-lg-12'>
                          <h4>KYC Details</h4>
                        </div>
                        <div className='col-lg-12'>
                          <div className='row'>
                            <div className='col-lg-6'>
                              <Form.Group
                                controlId='formgstnumber'
                                className='form-group document-file-input common-input-file  uploaded-doc'
                              >
                                <Form.Label>Upload Pan Card</Form.Label>
                                <Form.Control
                                  type='file'
                                  className='hidden-file'
                                  name='panCardFiles'
                                  {...register('panCardFiles', {
                                    required: true
                                  })}
                                  onChange={(e) => {
                                    onChange(e)
                                    setPanCardImage(e.target.files[0])
                                  }}
                                  accept="image/*"
                                />
                                <div className='form-control d-flex align-items-center flex-column justify-content-center text-center'>
                                  <div className='img-box'>
                                    <>
                                      <img src={typeof selectedPanCard === 'string' ? `${process.env.REACT_APP_AXIOS_BASE_URL}${selectedPanCard}` : typeof selectedPanCard === 'object' && selectedPanCard !== null ? URL?.createObjectURL(selectedPanCard) : otherdocPlaceholder} alt='' />
                                      {typeof selectedPanCard !== 'undefined' && <button
                                        className='close-cross-btn'
                                        onClick={(e) =>
                                          handleImageClose(e, 'panCardFile')
                                        }
                                      >
                                        <img src={crossWhite} alt='' />
                                      </button>}
                                    </>
                                  </div>
                                </div>
                              </Form.Group>
                            </div>
                          </div>
                        </div>
                        <div className='col-lg-12'>
                          <div className='row align-items-end'>
                            <div className='col-lg-6'>
                              <Form.Group
                                controlId='formgstnumber'
                                className='form-group document-file-input common-input-file  uploaded-doc'
                              >
                                <Form.Label>Update Aadhar card</Form.Label>
                                <Form.Control
                                  type='file'
                                  className='hidden-file'
                                  name='frontAdharCard'
                                  {...register('frontAdharCard', {
                                    required: true
                                  })}
                                  onChange={(e) => {
                                    onChange(e)
                                    setACardFront(e.target.files[0])
                                  }}
                                />
                                <div className='form-control d-flex align-items-center flex-column justify-content-center text-center'>
                                  <div className='img-box'>
                                  <>
                                      <img src={typeof selectedACardFront === 'string' ? `${process.env.REACT_APP_AXIOS_BASE_URL}${selectedACardFront}` : typeof selectedACardFront === 'object' && selectedACardFront !== null ? URL?.createObjectURL(selectedACardFront) : otherdocPlaceholder} alt='' />
                                      {typeof selectedACardFront !== 'undefined' && <button
                                        className='close-cross-btn'
                                        onClick={(e) =>
                                          handleImageClose(e, 'frontAdharCard')
                                        }
                                      >
                                        <img src={crossWhite} alt='' />
                                      </button>}
                                    </>
                                  </div>
                                </div>
                              </Form.Group>
                            </div>
                            <div className='col-lg-6'>
                              <Form.Group
                                controlId='formgstnumber'
                                className='form-group document-file-input common-input-file  uploaded-doc'
                              >
                                <Form.Control
                                  type='file'
                                  className='hidden-file'
                                  name='backAdharCard'
                                  {...register('backAdharCard', {
                                    required: true
                                  })}
                                  onChange={(e) => {
                                    onChange(e)
                                    setACardBack(e.target.files[0])
                                  }}
                                  accept="image/*"
                                />
                                <div className='form-control d-flex align-items-center flex-column justify-content-center text-center'>
                                  <div className='img-box'>
                                    <>
                                      <img src={typeof selectedACardBack === 'string' ? `${process.env.REACT_APP_AXIOS_BASE_URL}${selectedACardBack}` : typeof selectedACardBack === 'object' && selectedACardBack !== null ? URL.createObjectURL(selectedACardBack) : otherdocPlaceholder } alt='' />
                                      {typeof selectedACardBack !== 'undefined' && <button
                                        className='close-cross-btn'
                                        onClick={(e) =>
                                          handleImageClose(e, 'backAdharCard')
                                        }
                                      >
                                        <img src={crossWhite} alt='' />
                                      </button>}
                                    </>
                                  </div>
                                </div>
                              </Form.Group>
                            </div>
                          </div>
                        </div>
                        <div className='col-lg-6'>
                          <Form.Group
                            controlId='formgstnumber'
                            className='form-group document-file-input common-input-file  uploaded-doc'
                          >
                            <Form.Label>Update Signature</Form.Label>
                            <Form.Control
                              type='file'
                              className='hidden-file'
                              name='signature'
                              {...register('signature', {
                                required: true
                              })}
                              onChange={(e) => {
                                onChange(e)
                                setSignature(e.target.files[0])
                              }}
                              accept="image/*"
                            />
                            <div className='form-control d-flex align-items-center flex-column justify-content-center text-center'>
                              <div className='img-box'>
                                <>
                                      <img src={typeof signature === 'string' ? `${process.env.REACT_APP_AXIOS_BASE_URL}${signature}` : typeof signature === 'object' && signature !== null ? URL.createObjectURL(signature) : otherdocPlaceholder} alt='' />
                                      {typeof signature !== 'undefined' && <button
                                        className='close-cross-btn'
                                        onClick={(e) =>
                                          handleImageClose(e, 'signature')
                                        }
                                      >
                                        <img src={crossWhite} alt='' />
                                      </button>}
                                    </>
                              </div>
                            </div>
                          </Form.Group>
                        </div>
                        <div className='col-lg-6'>

                        </div>
                        <div className='col-lg-6'>
                        <Form.Group
                            controlId='formgstnumber'
                            className='form-group document-file-input common-input-file  uploaded-doc'
                          >
                            <Form.Label>Types</Form.Label>
                            <Form.Check
                            type='checkbox'
                          >
                            <Form.Check.Input
                              name='is_image'
                              checked={careerChecked}
                              // onChange={(e) => handleCheckboxChange(e, 'career')}
                              onChange={() => {
                                setCareerChecked(!careerChecked)
                              }}
                            />
                              <Form.Check.Label>
                                 Career Counsellor
                              </Form.Check.Label>
                              </Form.Check>
                              <Form.Check
                                type='checkbox'
                              >
                                <Form.Check.Input
                                  name='is_math'
                                  type='checkbox'
                                  checked={psyChecked}
                                  // onChange={(e) => handleCheckboxChange(e, 'career')}
                                  onChange={() => {
                                    setPsyChecked(!psyChecked)
                                  }}
                                />
                              <Form.Check.Label>
                                 Psychologist
                              </Form.Check.Label>
                            </Form.Check>
                            <Form.Check
                              type='checkbox'
                            >
                              <Form.Check.Input
                                type='checkbox'
                                name='is_correct_ans'
                                checked={overChecked}
                                onChange={() => {
                                  setOverChecked(!overChecked)
                                }}
                              />
                                <Form.Check.Label>
                                  Overseas Counsellor
                                </Form.Check.Label>
                                </Form.Check>
                                <Form.Check
                                  type='checkbox'
                                >
                                  <Form.Check.Input
                                    type='checkbox'
                                    name='is_correct_ans'
                                    checked={studentExpert}
                                    onChange={() => {
                                      setStudentExpert(!studentExpert)
                                    }}
                                  />
                                    <Form.Check.Label>
                                      Student Expert Counsellor
                                    </Form.Check.Label>
                                </Form.Check>
                          </Form.Group>
                           {careerChecked === false && psyChecked === false && overChecked === false && studentExpert === false && (
                              <Form.Text className='error-msg'>
                                Please select any one counsellor type
                              </Form.Text>
                           )}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </Form>
        </div>

    </>
  )
}

export default Editmyprofile
